/*package com.example.ventilationintelligente

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.*
import kotlin.random.Random

// === UUIDs (Identiques au nRF52) ===
val SERVICE_UUID: UUID = UUID.fromString("12121000-EFDE-1523-785F-EABCD1230000")
val CHAR_DATA_UUID: UUID = UUID.fromString("12122A01-EFDE-1523-785F-EABCD1230000")
val CHAR_CMD_UUID: UUID = UUID.fromString("12122A02-EFDE-1523-785F-EABCD1230000")
val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805F9B34FB")

class MainActivity : ComponentActivity() {

    // États observables pour l'interface Compose
    private var temp by mutableFloatStateOf(0f)
    private var hum by mutableFloatStateOf(0f)
    private var iaq by mutableIntStateOf(0)
    private var verinState by mutableIntStateOf(0) // 0: Fermé, 1: Ouvert
    private var isAutoMode by mutableStateOf(true)
    private var connectionStatus by mutableStateOf("Déconnecté")

    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bluetoothGatt: BluetoothGatt? = null
    private var previousVerinState = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Setup Bluetooth
        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter
        createNotificationChannel()

        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    VentilationAppContent(
                        temp = temp,
                        hum = hum,
                        iaq = iaq,
                        verinState = verinState,
                        isAutoMode = isAutoMode,
                        status = connectionStatus,
                        onModeChange = { auto ->
                            isAutoMode = auto
                            sendCommand(if (auto) 0 else 99) // 0=Auto, 99=Juste switch mode (pas d'action verin immediate)
                        },
                        onManualAction = { open ->
                            sendCommand(if (open) 1 else 2) // 1=Ouvrir, 2=Fermer
                        },
                        onStartScan = { startBleScan() }
                    )
                }
            }
        }
    }

    // --- LOGIQUE BLE (BACKEND) ---

    @SuppressLint("MissingPermission")
    private fun startBleScan() {
        if (bluetoothAdapter == null || !bluetoothAdapter!!.isEnabled) {
            connectionStatus = "Bluetooth éteint"
            return
        }

        connectionStatus = "Recherche SmartVent_Central..."
        bluetoothAdapter?.bluetoothLeScanner?.startScan(scanCallback)
    }

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            if (device.name == "SmartVent_Central") {
                bluetoothAdapter?.bluetoothLeScanner?.stopScan(this)
                connectionStatus = "Connexion..."
                device.connectGatt(this@MainActivity, false, gattCallback)
            }
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                connectionStatus = "Connecté ! Découverte..."
                bluetoothGatt = gatt
                gatt.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connectionStatus = "Déconnecté"
                bluetoothGatt = null
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            val service = gatt.getService(SERVICE_UUID)
            val charac = service?.getCharacteristic(CHAR_DATA_UUID)
            if (charac != null) {
                gatt.setCharacteristicNotification(charac, true)
                val descriptor = charac.getDescriptor(CCCD_UUID)
                descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                gatt.writeDescriptor(descriptor)
            }
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            // Callback pour Android 13+
            parseData(value)
        }

        @Deprecated("Deprecated in Java")
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            // Callback pour Android 12 et moins
            parseData(characteristic.value)
        }
    }

    private fun parseData(data: ByteArray) {
        if (data.size < 14) return
        val buffer = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN)

        // Mise à jour des variables d'état (Compose réagira automatiquement)
        temp = buffer.float
        hum = buffer.float
        iaq = buffer.int
        val newState = buffer.get().toInt()
        val mode = buffer.get().toInt()

        verinState = newState

        // Synchro mode auto/manuel si changé par le nRF
        if (mode == 0) isAutoMode = true
        else if (mode != 0 && isAutoMode) isAutoMode = false

        checkNotifications(newState)
    }

    @SuppressLint("MissingPermission")
    private fun sendCommand(cmd: Int) {
        val service = bluetoothGatt?.getService(SERVICE_UUID)
        val charac = service?.getCharacteristic(CHAR_CMD_UUID) ?: return

        charac.value = byteArrayOf(cmd.toByte())
        charac.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        bluetoothGatt?.writeCharacteristic(charac)
    }

    // --- NOTIFICATIONS ---
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("VENT_CHANNEL", "Alertes Ventilation", NotificationManager.IMPORTANCE_DEFAULT)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    @SuppressLint("MissingPermission")
    private fun checkNotifications(currentState: Int) {
        if (previousVerinState != -1 && currentState != previousVerinState) {
            val title = if (currentState == 1) "Ventilation Active" else "Ventilation Stoppée"
            val text = if (currentState == 1) "Ouverture vérin : Mauvais air détecté." else "Fermeture vérin : Air purifié."

            val builder = NotificationCompat.Builder(this, "VENT_CHANNEL")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)

            NotificationManagerCompat.from(this).notify(Random.nextInt(), builder.build())
        }
        previousVerinState = currentState
    }
}

// === INTERFACE UTILISATEUR (COMPOSE) ===

@Composable
fun VentilationAppContent(
    temp: Float, hum: Float, iaq: Int, verinState: Int, isAutoMode: Boolean, status: String,
    onModeChange: (Boolean) -> Unit,
    onManualAction: (Boolean) -> Unit,
    onStartScan: () -> Unit
) {
    // Gestion Permission au lancement
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        onStartScan()
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 31) {
            launcher.launch(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.POST_NOTIFICATIONS))
        } else {
            launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.BLUETOOTH))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Smart Ventilation", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

        Spacer(modifier = Modifier.height(30.dp))

        // JAUGE IAQ
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(220.dp)) {
            val progressColor by animateColorAsState(if (iaq > 80) Color.Green else if (iaq > 50) Color.Yellow else Color.Red)

            CircularProgressIndicator(
                progress = { 1f }, // Fond gris complet
                modifier = Modifier.fillMaxSize(),
                color = Color.LightGray.copy(alpha = 0.3f),
                strokeWidth = 20.dp,
            )
            CircularProgressIndicator(
                progress = { iaq / 100f },
                modifier = Modifier.fillMaxSize(),
                color = progressColor,
                strokeWidth = 20.dp,
                strokeCap = StrokeCap.Round,
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$iaq%", fontSize = 48.sp, fontWeight = FontWeight.Bold)
                Text("Capacité Air", fontSize = 14.sp, color = Color.Gray)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
        Text(status, color = Color(0xFFE91E63))
        Spacer(modifier = Modifier.height(20.dp))

        // CARTES TEMP / HUM
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            InfoCard(title = "Température", value = String.format("%.1f°C", temp), modifier = Modifier.weight(1f))
            InfoCard(title = "Humidité", value = String.format("%.1f%%", hum), modifier = Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(24.dp))

        // CONTRÔLES
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Contrôle Vérin", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Mode Automatique", modifier = Modifier.weight(1f))
                    Switch(checked = isAutoMode, onCheckedChange = onModeChange)
                }

                if (!isAutoMode) {
                    Spacer(modifier = Modifier.height(15.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { onManualAction(true) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))) {
                            Text("OUVRIR")
                        }
                        Button(onClick = { onManualAction(false) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF44336))) {
                            Text("FERMER")
                        }
                    }
                }

                Spacer(modifier = Modifier.height(15.dp))
                val stateText = if (verinState == 1) "ÉTAT : OUVERT (Aération)" else "ÉTAT : FERMÉ (Eco)"
                val stateColor = if (verinState == 1) Color.Red else Color(0xFF4CAF50)
                Text(stateText, color = stateColor, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

@Composable
fun InfoCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, elevation = CardDefaults.cardElevation(4.dp)) {
        Column(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, fontSize = 14.sp)
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
}*/

/*
package com.example.ventilationintelligente

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import java.util.*

// === UUIDs DU SERVICE LBS (NORDIC BLINKY) ===
// Ces UUIDs correspondent à ceux utilisés dans ton code C "Verin_BLE"
val LBS_SERVICE_UUID: UUID = UUID.fromString("00001523-1212-EFDE-1523-785FEABCD123")
val LBS_CMD_CHAR_UUID: UUID = UUID.fromString("00001525-1212-EFDE-1523-785FEABCD123") // LED Characteristic (Write)

class MainActivity : ComponentActivity() {

    // États de l'interface
    private var connectionStatus by mutableStateOf("Déconnecté")
    private var isConnected by mutableStateOf(false)
    private var lastAction by mutableStateOf("Aucune")

    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bluetoothGatt: BluetoothGatt? = null
    private var commandCharacteristic: BluetoothGattCharacteristic? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter

        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    VerinTestInterface(
                        status = connectionStatus,
                        isConnected = isConnected,
                        lastAction = lastAction,
                        onScanClick = { startBleScan() },
                        onCommandClick = { cmd -> sendCommand(cmd) },
                        onDisconnectClick = { disconnect() }
                    )
                }
            }
        }
    }

    // --- LOGIQUE BLE ---

    @SuppressLint("MissingPermission")
    private fun startBleScan() {
        if (bluetoothAdapter == null || !bluetoothAdapter!!.isEnabled) {
            connectionStatus = "Bluetooth éteint !"
            return
        }

        connectionStatus = "Recherche 'Verin_BLE'..."
        // On scanne sans filtre UUID pour être sûr de le trouver par nom
        bluetoothAdapter?.bluetoothLeScanner?.startScan(scanCallback)
    }

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            // FILTRE SUR LE NOM EXACT QUI APPARAIT DANS NRF CONNECT
            if (device.name == "Verin_BLE") {
                connectionStatus = "Trouvé ! Connexion..."
                bluetoothAdapter?.bluetoothLeScanner?.stopScan(this)
                device.connectGatt(this@MainActivity, false, gattCallback)
            }
        }
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                connectionStatus = "Connecté. Découverte Services..."
                bluetoothGatt = gatt
                gatt.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connectionStatus = "Déconnecté"
                isConnected = false
                bluetoothGatt = null
            }
        }

        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            val service = gatt.getService(LBS_SERVICE_UUID)
            if (service != null) {
                commandCharacteristic = service.getCharacteristic(LBS_CMD_CHAR_UUID)
                if (commandCharacteristic != null) {
                    isConnected = true
                    connectionStatus = "PRÊT À COMMANDER"
                } else {
                    connectionStatus = "Erreur: Caractéristique CMD introuvable"
                }
            } else {
                connectionStatus = "Erreur: Service LBS introuvable"
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun sendCommand(cmd: Int) {
        if (bluetoothGatt == null || commandCharacteristic == null) {
            connectionStatus = "Erreur: Non connecté"
            return
        }

        // Envoi de la commande (1=Ouvrir, 2=Fermer, 3=Stop)
        commandCharacteristic?.value = byteArrayOf(cmd.toByte())
        commandCharacteristic?.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT

        // Pour Android 13 (Tiramisu) et plus, ou versions antérieures
        if (Build.VERSION.SDK_INT >= 33) {
            bluetoothGatt?.writeCharacteristic(commandCharacteristic!!, commandCharacteristic!!.value, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT)
        } else {
            bluetoothGatt?.writeCharacteristic(commandCharacteristic!!)
        }

        // Mise à jour UI
        lastAction = when(cmd) {
            1 -> "OUVERTURE (Cmd: 1)"
            2 -> "FERMETURE (Cmd: 2)"
            3 -> "STOP (Cmd: 3)"
            else -> "Inconnu"
        }
    }

    @SuppressLint("MissingPermission")
    private fun disconnect() {
        bluetoothGatt?.disconnect()
        bluetoothGatt?.close()
        bluetoothGatt = null
        connectionStatus = "Déconnecté"
        isConnected = false
    }
}

// === INTERFACE UTILISATEUR ===

@Composable
fun VerinTestInterface(
    status: String,
    isConnected: Boolean,
    lastAction: String,
    onScanClick: () -> Unit,
    onCommandClick: (Int) -> Unit,
    onDisconnectClick: () -> Unit
) {
    // Gestion Permission
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 31) {
            launcher.launch(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT))
        } else {
            launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.BLUETOOTH))
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("TEST DIRECT VÉRIN", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.Blue)
        Spacer(modifier = Modifier.height(30.dp))

        // Indicateur d'état
        Card(
            colors = CardDefaults.cardColors(containerColor = if (isConnected) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)),
            modifier = Modifier.fillMaxWidth().padding(10.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("État : $status", fontWeight = FontWeight.Bold, color = if (isConnected) Color(0xFF2E7D32) else Color.Red)
                Spacer(modifier = Modifier.height(5.dp))
                Text("Dernière Action : $lastAction", fontSize = 14.sp, color = Color.Gray)
            }
        }

        Spacer(modifier = Modifier.height(30.dp))

        if (!isConnected) {
            Button(
                onClick = onScanClick,
                modifier = Modifier.size(width = 200.dp, height = 50.dp)
            ) {
                Text("SCANNER 'Verin_BLE'")
            }
        } else {
            // Boutons de Commande
            Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { onCommandClick(1) }, // 1 = Ouvrir
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                    modifier = Modifier.weight(1f).padding(4.dp)
                ) {
                    Text("OUVRIR")
                }

                Button(
                    onClick = { onCommandClick(2) }, // 2 = Fermer
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF44336)),
                    modifier = Modifier.weight(1f).padding(4.dp)
                ) {
                    Text("FERMER")
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = { onCommandClick(3) }, // 3 = Stop
                colors = ButtonDefaults.buttonColors(containerColor = Color.Gray),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
            ) {
                Text("STOP / ARRÊT URGENCE")
            }

            Spacer(modifier = Modifier.height(30.dp))
            OutlinedButton(onClick = onDisconnectClick) {
                Text("Déconnecter")
            }
        }
    }
}
*/


/*
package com.example.ventilationintelligente

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.util.*
import kotlin.random.Random

// === UUIDs VALIDÉS PAR TA CAPTURE D'ÉCRAN (Nordic UART Service) ===
val NUS_SERVICE_UUID: UUID = UUID.fromString("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
val NUS_RX_CHAR_UUID: UUID = UUID.fromString("6E400002-B5A3-F393-E0A9-E50E24DCCA9E") // Ecriture
val NUS_TX_CHAR_UUID: UUID = UUID.fromString("6E400003-B5A3-F393-E0A9-E50E24DCCA9E") // Lecture
val CCCD_UUID: UUID        = UUID.fromString("00002902-0000-1000-8000-00805F9B34FB")

class MainActivity : ComponentActivity() {

    private var connectionStatus by mutableStateOf("Prêt")
    private var isConnected by mutableStateOf(false)
    private var temp by mutableFloatStateOf(0f)
    private var hum by mutableFloatStateOf(0f)
    private var iaq by mutableIntStateOf(0)

    // Logs et Liste Bluetooth
    private val logMessages = mutableStateListOf<String>()
    private val scannedDevices = mutableStateListOf<Pair<BluetoothDevice, Int>>()

    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bluetoothGatt: BluetoothGatt? = null
    private var rxCharacteristic: BluetoothGattCharacteristic? = null
    private var isScanning = false
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 1. Anti-Crash : Capture les erreurs
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            Log.e("BLE_CRASH", "Erreur Fatale: ${e.message}")
        }

        // 2. Init Bluetooth
        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter
        createNotificationChannel()

        setContent {
            MaterialTheme {
                MainScreen()
            }
        }
    }

    // --- SCAN ---
    @SuppressLint("MissingPermission")
    private fun startScan() {
        if (bluetoothAdapter == null || !bluetoothAdapter!!.isEnabled) {
            connectionStatus = "Bluetooth éteint !"
            return
        }

        scannedDevices.clear()
        connectionStatus = "Recherche..."
        isScanning = true

        try {
            bluetoothAdapter?.bluetoothLeScanner?.startScan(scanCallback)
            // Stop auto après 10s
            handler.postDelayed({ stopScan() }, 10000)
        } catch (e: Exception) {
            connectionStatus = "Erreur Scan: ${e.message}"
            isScanning = false
        }
    }

    @SuppressLint("MissingPermission")
    private fun stopScan() {
        if (!isScanning) return
        try {
            bluetoothAdapter?.bluetoothLeScanner?.stopScan(scanCallback)
            connectionStatus = "Scan terminé"
        } catch (e: Exception) {}
        isScanning = false
    }

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            // On affiche TOUT ce qui a un nom
            if (device.name != null) {
                if (!scannedDevices.any { it.first.address == device.address }) {
                    scannedDevices.add(Pair(device, result.rssi))
                }
            }
        }
        override fun onScanFailed(errorCode: Int) {
            connectionStatus = "Echec Scan ($errorCode)"
            isScanning = false
        }
    }

    // --- CONNEXION ---
    @SuppressLint("MissingPermission")
    private fun connectTo(device: BluetoothDevice) {
        stopScan()
        connectionStatus = "Connexion à ${device.name}..."
        try {
            device.connectGatt(this, false, gattCallback)
        } catch (e: Exception) {
            connectionStatus = "Erreur Connexion: ${e.message}"
        }
    }

    @SuppressLint("MissingPermission")
    private fun disconnect() {
        bluetoothGatt?.disconnect()
        bluetoothGatt?.close()
        bluetoothGatt = null
        isConnected = false
        connectionStatus = "Déconnecté"
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread { connectionStatus = "Connecté ! Recherche..." }
                bluetoothGatt = gatt
                gatt.discoverServices()
                runOnUiThread { isConnected = true }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                runOnUiThread {
                    connectionStatus = "Déconnecté"
                    isConnected = false
                }
                bluetoothGatt = null
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            val service = gatt.getService(NUS_SERVICE_UUID)
            if (service != null) {
                rxCharacteristic = service.getCharacteristic(NUS_RX_CHAR_UUID)
                val txChar = service.getCharacteristic(NUS_TX_CHAR_UUID)

                if (txChar != null) {
                    gatt.setCharacteristicNotification(txChar, true)
                    val descriptor = txChar.getDescriptor(CCCD_UUID)
                    if(descriptor != null) {
                        descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        gatt.writeDescriptor(descriptor)
                        runOnUiThread { connectionStatus = "Données en direct" }
                    }
                }
            } else {
                runOnUiThread { connectionStatus = "Erreur: Ce n'est pas AirMonitor (Pas de NUS)" }
            }
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
            parseData(value)
        }

        @Deprecated("Deprecated in Java")
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            parseData(characteristic.value)
        }
    }

    private fun parseData(data: ByteArray) {
        val text = String(data).trim()
        runOnUiThread {
            // Regex correspondant à ta capture: T:22C H:48% IAQ:77
            val regex = """T:(\d+)C H:(\d+)% IAQ:(\d+)""".toRegex()
            val matchResult = regex.find(text)

            if (matchResult != null) {
                val (t, h, q) = matchResult.destructured
                temp = t.toFloat()
                hum = h.toFloat()
                iaq = q.toInt()
            } else {
                // Messages système
                logMessages.add(0, "${getTime()} - $text")
                if (logMessages.size > 20) logMessages.removeLast()

                if (text.contains("ALERTE") || text.contains("Action")) {
                    sendNotif("Smart Ventilation", text)
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun sendCommand(cmd: String) {
        if (bluetoothGatt == null || rxCharacteristic == null) return
        rxCharacteristic?.value = cmd.toByteArray()
        rxCharacteristic?.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        bluetoothGatt?.writeCharacteristic(rxCharacteristic!!)
    }

    // --- UI ---
    @Composable
    fun MainScreen() {
        var selectedTab by remember { mutableIntStateOf(0) }

        // Permission Launcher
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}
        LaunchedEffect(Unit) {
            if (Build.VERSION.SDK_INT >= 31) {
                launcher.launch(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.POST_NOTIFICATIONS))
            } else {
                launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.BLUETOOTH))
            }
        }

        Scaffold(
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(icon = { Icon(Icons.Default.Search, "Scan") }, label = { Text("Scanner") }, selected = selectedTab == 0, onClick = { selectedTab = 0 })
                    NavigationBarItem(icon = { Icon(Icons.Default.Home, "Dash") }, label = { Text("Contrôle") }, selected = selectedTab == 1, onClick = { selectedTab = 1 })
                }
            }
        ) { innerPadding ->
            Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
                if (selectedTab == 0) {
                    ScanScreen(scannedDevices, connectionStatus, isScanning, { startScan() }, {
                        connectTo(it)
                        selectedTab = 1
                    })
                } else {
                    DashboardScreen(isConnected, connectionStatus, temp, hum, iaq, logMessages, { sendCommand(it) }, { disconnect() })
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    @Composable
    fun ScanScreen(devices: List<Pair<BluetoothDevice, Int>>, status: String, scanning: Boolean, onScan: () -> Unit, onConnect: (BluetoothDevice) -> Unit) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Appareils Bluetooth", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Button(onClick = onScan) { if(scanning) Text("Stop") else Text("Scanner") }
            }
            Text(status, color = Color.Gray, fontSize = 12.sp)
            Divider(modifier = Modifier.padding(vertical = 10.dp))

            LazyColumn {
                items(devices) { (device, rssi) ->
                    Card(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { onConnect(device) }, elevation = CardDefaults.cardElevation(2.dp)) {
                        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(device.name ?: "Inconnu", fontWeight = FontWeight.Bold)
                                Text(device.address, fontSize = 10.sp, color = Color.Gray)
                            }
                            Text("$rssi dBm", fontWeight = FontWeight.Bold, color = if(rssi > -60) Color(0xFF4CAF50) else Color.Gray)
                        }
                    }
                }
            }
        }
    }

    @Composable
    fun DashboardScreen(isConnected: Boolean, status: String, temp: Float, hum: Float, iaq: Int, logs: List<String>, onCommand: (String) -> Unit, onDisconnect: () -> Unit) {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text("Air Monitor", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary, modifier = Modifier.weight(1f))
                if(isConnected) Button(onClick = onDisconnect, colors = ButtonDefaults.buttonColors(Color(0xFFF44336))) { Text("Déco") }
            }
            Text("État: $status", fontSize = 14.sp, color = if(isConnected) Color(0xFF4CAF50) else Color.Red)
            Spacer(modifier = Modifier.height(20.dp))

            if (!isConnected) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Non connecté. Allez dans l'onglet Scanner.", color = Color.Gray) }
            } else {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(180.dp)) {
                    val color by animateColorAsState(if (iaq > 80) Color(0xFF4CAF50) else if (iaq > 50) Color(0xFFFFC107) else Color(0xFFF44336))
                    CircularProgressIndicator(progress = 1f, color = Color.LightGray.copy(alpha=0.3f), strokeWidth = 15.dp, modifier = Modifier.fillMaxSize())
                    CircularProgressIndicator(progress = iaq / 100f, color = color, strokeWidth = 15.dp, strokeCap = StrokeCap.Round, modifier = Modifier.fillMaxSize())
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("$iaq%", fontSize = 42.sp, fontWeight = FontWeight.Bold)
                        Text("Qualité Air", fontSize = 12.sp, color = Color.Gray)
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    InfoCard("Température", "${temp.toInt()}°C", Color(0xFFFF9800), Modifier.weight(1f))
                    InfoCard("Humidité", "${hum.toInt()}%", Color(0xFF2196F3), Modifier.weight(1f))
                }
                Spacer(modifier = Modifier.height(24.dp))
                Text("Contrôle Manuel", fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { onCommand("1") }, colors = ButtonDefaults.buttonColors(Color(0xFF4CAF50)), modifier = Modifier.weight(1f)) { Text("OUVRIR") }
                    Button(onClick = { onCommand("3") }, colors = ButtonDefaults.buttonColors(Color.Gray), modifier = Modifier.weight(0.6f)) { Text("STOP") }
                    Button(onClick = { onCommand("2") }, colors = ButtonDefaults.buttonColors(Color(0xFFF44336)), modifier = Modifier.weight(1f)) { Text("FERMER") }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Card(colors = CardDefaults.cardColors(Color(0xFFF5F5F5)), modifier = Modifier.fillMaxWidth().weight(1f)) {
                    LazyColumn(Modifier.padding(10.dp)) { items(logs) { log -> Text(log, fontSize = 11.sp) } }
                }
            }
        }
    }

    @Composable
    fun InfoCard(title: String, value: String, color: Color, modifier: Modifier) {
        Card(colors = CardDefaults.cardColors(Color.White), elevation = CardDefaults.cardElevation(4.dp), modifier = modifier) {
            Column(Modifier.padding(16.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(title, fontSize = 12.sp, color = Color.Gray)
                Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = color)
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("VENT_NOTIF", "Alertes Air", NotificationManager.IMPORTANCE_HIGH)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    @SuppressLint("MissingPermission")
    private fun sendNotif(title: String, content: String) {
        val builder = NotificationCompat.Builder(this, "VENT_NOTIF")
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(content)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
        NotificationManagerCompat.from(this).notify(Random.nextInt(), builder.build())
    }

    private fun getTime(): String = java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
}
*/


package com.example.ventilationintelligente

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColor
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.util.*
import kotlin.random.Random

// === UUIDs (Service Nordic UART) ===
val NUS_SERVICE_UUID: UUID = UUID.fromString("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
val NUS_RX_CHAR_UUID: UUID = UUID.fromString("6E400002-B5A3-F393-E0A9-E50E24DCCA9E")
val NUS_TX_CHAR_UUID: UUID = UUID.fromString("6E400003-B5A3-F393-E0A9-E50E24DCCA9E")
val CCCD_UUID: UUID        = UUID.fromString("00002902-0000-1000-8000-00805F9B34FB")

// === PALETTE COULEURS "TECH PRO 2025" ===
val SlateDark = Color(0xFF1E293B)
val SlateLight = Color(0xFFF1F5F9)
val TechBlue = Color(0xFF3B82F6)
val SensorCyan = Color(0xFF06B6D4)
val AlertOrange = Color(0xFFF97316)
val CriticalRed = Color(0xFFDC2626)
val SuccessGreen = Color(0xFF10B981)
val SurfaceWhite = Color(0xFFFFFFFF)

class MainActivity : ComponentActivity() {

    // Etats Bluetooth & Capteurs
    private var connectionStatus by mutableStateOf("STANDBY")
    private var isConnected by mutableStateOf(false)
    private var temp by mutableFloatStateOf(0f)
    private var hum by mutableFloatStateOf(0f)
    private var iaq by mutableIntStateOf(0)

    // Etats Sécurité & Alertes
    private var isFireMode by mutableStateOf(false)
    private var lastAlertTime = 0L
    private val ALERT_COOLDOWN = 60000L

    // Données Historiques
    private val iaqHistory = mutableStateListOf<Int>()
    private val logMessages = mutableStateListOf<String>()
    private val scannedDevices = mutableStateListOf<Pair<BluetoothDevice, Int>>()

    // Système
    private var bluetoothAdapter: BluetoothAdapter? = null
    private var bluetoothGatt: BluetoothGatt? = null
    private var rxCharacteristic: BluetoothGattCharacteristic? = null
    private var isScanning = false
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Anti-Crash global
        Thread.setDefaultUncaughtExceptionHandler { _, e -> Log.e("BLE_CRASH", "Err: ${e.message}") }

        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter
        createNotificationChannel()

        // Initialisation du graphique (pour éviter qu'il soit vide)
        for(i in 0..20) iaqHistory.add(0)

        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(primary = TechBlue, background = SlateLight, surface = SurfaceWhite)
            ) {
                MainScreen()
            }
        }
    }

    // ==========================================
    // LOGIQUE BLUETOOTH & SÉCURITÉ
    // ==========================================

    @SuppressLint("MissingPermission")
    private fun startScan() {
        if (bluetoothAdapter == null || !bluetoothAdapter!!.isEnabled) return
        scannedDevices.clear()
        connectionStatus = "SCANNING..."
        isScanning = true
        try {
            bluetoothAdapter?.bluetoothLeScanner?.startScan(scanCallback)
            handler.postDelayed({ stopScan() }, 8000)
        } catch (e: Exception) { connectionStatus = "ERR: ${e.message}"; isScanning = false }
    }

    @SuppressLint("MissingPermission")
    private fun stopScan() {
        if (!isScanning) return
        try {
            bluetoothAdapter?.bluetoothLeScanner?.stopScan(scanCallback)
            connectionStatus = "IDLE"
        } catch (e: Exception) {}
        isScanning = false
    }

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            if (device.name != null) {
                var exists = false
                for (pair in scannedDevices) {
                    if (pair.first.address == device.address) { exists = true; break }
                }
                if (!exists) scannedDevices.add(Pair(device, result.rssi))
            }
        }
        override fun onScanFailed(errorCode: Int) { isScanning = false; connectionStatus = "ERR_SCAN_$errorCode" }
    }

    @SuppressLint("MissingPermission")
    private fun connectTo(device: BluetoothDevice) {
        stopScan()
        connectionStatus = "CONNECTING..."
        try { device.connectGatt(this, false, gattCallback) } catch (e: Exception) {}
    }

    @SuppressLint("MissingPermission")
    private fun disconnect() {
        bluetoothGatt?.disconnect(); bluetoothGatt?.close(); bluetoothGatt = null
        isConnected = false; connectionStatus = "DISCONNECTED"
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                runOnUiThread { connectionStatus = "SYNCING..." }
                bluetoothGatt = gatt; gatt.discoverServices(); runOnUiThread { isConnected = true }
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                runOnUiThread { connectionStatus = "DISCONNECTED"; isConnected = false }; bluetoothGatt = null
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            val service = gatt.getService(NUS_SERVICE_UUID)
            if (service != null) {
                rxCharacteristic = service.getCharacteristic(NUS_RX_CHAR_UUID)
                val txChar = service.getCharacteristic(NUS_TX_CHAR_UUID)
                if (txChar != null) {
                    gatt.setCharacteristicNotification(txChar, true)
                    val descriptor = txChar.getDescriptor(CCCD_UUID)
                    if(descriptor != null) {
                        descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        gatt.writeDescriptor(descriptor)
                        runOnUiThread { connectionStatus = "ONLINE :: DATA STREAM" }
                    }
                }
            }
        }

        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) { parseData(value) }
        @Deprecated("Deprecated in Java")
        override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) { parseData(characteristic.value) }
    }

    private fun parseData(data: ByteArray) {
        val text = String(data).trim()
        runOnUiThread {
            val regex = """T:(\d+)C H:(\d+)% IAQ:(\d+)""".toRegex()
            val matchResult = regex.find(text)
            if (matchResult != null) {
                val (t, h, q) = matchResult.destructured
                temp = t.toFloat(); hum = h.toFloat(); iaq = q.toInt()

                // Mise à jour Graphique
                iaqHistory.add(iaq)
                if (iaqHistory.size > 30) iaqHistory.removeAt(0)

                // Vérification Alertes (Normal mode = false pour force)
                checkSafetyRules(temp, hum, iaq, force = false)
            } else {
                logMessages.add(0, "${getTime()} > $text")
                if (logMessages.size > 20) logMessages.removeLast()
            }
        }
    }

    // Le cerveau de la sécurité (avec option 'force' pour la simulation)
    private fun checkSafetyRules(t: Float, h: Float, q: Int, force: Boolean) {
        val currentTime = System.currentTimeMillis()

        // 1. INCENDIE (Urgence Absolue)
        if (t > 45 || q > 300) {
            if (!isFireMode) {
                isFireMode = true
                sendCommand("1") // Commande 1 = Ouvrir
                sendNotif("🔥 INCENDIE DÉTECTÉ", "TEMP: $t°C - EVACUATION FUMÉES ACTIVÉE")
            }
            return
        } else {
            // Désactivation auto si conditions normales (sauf si on est en simulation forcée)
            if (isFireMode && !force && t < 40 && q < 150) isFireMode = false
        }

        // 2. ALERTES MINEURES (Anti-Spam activé sauf si forcé)
        if (!force && currentTime - lastAlertTime < ALERT_COOLDOWN) return

        var alertTitle = ""
        if (q > 200) alertTitle = "⚠️ POLLUTION AIR ($q)"
        else if (h > 80) alertTitle = "💧 HUMIDITÉ CRITIQUE ($h%)"

        if (alertTitle.isNotEmpty()) {
            sendNotif(alertTitle, "Vérification ventilation requise.")
            lastAlertTime = currentTime
            logMessages.add(0, "ALERT: $alertTitle")
        }
    }

    @SuppressLint("MissingPermission")
    private fun sendCommand(cmd: String) {
        if (bluetoothGatt == null || rxCharacteristic == null) return
        rxCharacteristic?.value = cmd.toByteArray()
        rxCharacteristic?.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        bluetoothGatt?.writeCharacteristic(rxCharacteristic!!)
    }

    // ==========================================
    // INTERFACE UTILISATEUR (UI)
    // ==========================================

    @Composable
    fun MainScreen() {
        var selectedTab by remember { mutableIntStateOf(0) }
        val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

        LaunchedEffect(Unit) {
            if (Build.VERSION.SDK_INT >= 31) launcher.launch(arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.POST_NOTIFICATIONS))
            else launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.BLUETOOTH))
        }

        Scaffold(
            bottomBar = {
                NavigationBar(containerColor = SurfaceWhite, tonalElevation = 10.dp) {
                    NavigationBarItem(
                        icon = { Text("📡", fontSize = 20.sp) },
                        label = { Text("Scanner", fontFamily = FontFamily.Monospace, fontSize = 10.sp) }, selected = selectedTab == 0, onClick = { selectedTab = 0 }
                    )
                    NavigationBarItem(
                        icon = { Text("🎛️", fontSize = 20.sp) },
                        label = { Text("Système", fontFamily = FontFamily.Monospace, fontSize = 10.sp) }, selected = selectedTab == 1, onClick = { selectedTab = 1 }
                    )
                }
            }
        ) { innerPadding ->
            Box(modifier = Modifier.padding(innerPadding).fillMaxSize().background(SlateLight)) {
                if (selectedTab == 0) {
                    ScanScreen(scannedDevices, connectionStatus, isScanning, { startScan() }, { connectTo(it); selectedTab = 1 })
                } else {
                    DashboardScreen(
                        isConnected, connectionStatus, temp, hum, iaq, iaqHistory, logMessages,
                        onCommand = { sendCommand(it) },
                        onDisconnect = { disconnect() },
                        // Actions de Simulation pour la Démo
                        onSimulateFire = { checkSafetyRules(60f, 20f, 500, true) },
                        onSimulatePollution = { checkSafetyRules(22f, 40f, 250, true) },
                        onSimulateHumidity = { checkSafetyRules(22f, 95f, 50, true) }
                    )

                    // Overlay Incendie Prioritaire
                    if (isFireMode) FireAlertOverlay(temp) { isFireMode = false; sendCommand("2") }
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    @Composable
    fun ScanScreen(devices: List<Pair<BluetoothDevice, Int>>, status: String, scanning: Boolean, onScan: () -> Unit, onConnect: (BluetoothDevice) -> Unit) {
        Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {
            // Header
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(if(scanning) SuccessGreen else Color.Gray))
                Spacer(Modifier.width(10.dp))
                Text("SCANNER MODULES", fontSize = 20.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = SlateDark)
            }
            Text("STATUS: $status", fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = Color.Gray, modifier = Modifier.padding(start = 20.dp))
            Spacer(Modifier.height(20.dp))

            // Bouton Scan
            Button(onClick = onScan, modifier = Modifier.fillMaxWidth().height(50.dp), colors = ButtonDefaults.buttonColors(containerColor = TechBlue), shape = RoundedCornerShape(4.dp)) {
                if (scanning) CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                else Text("INITIALISER SCAN", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(20.dp))
            Divider(color = Color.LightGray)
            Spacer(Modifier.height(10.dp))

            // Liste
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(devices) { item ->
                    Row(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)).background(SurfaceWhite).border(1.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(4.dp)).clickable { onConnect(item.first) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.first.name ?: "UNKNOWN_DEVICE", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = SlateDark)
                            Text(item.first.address, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color.Gray)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("RSSI", fontSize = 8.sp, color = Color.Gray)
                            Text("${item.second} dB", fontWeight = FontWeight.Bold, color = if(item.second > -60) SuccessGreen else AlertOrange, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }

    @Composable
    fun DashboardScreen(
        isConnected: Boolean, status: String, temp: Float, hum: Float, iaq: Int,
        history: List<Int>, logs: List<String>,
        onCommand: (String) -> Unit, onDisconnect: () -> Unit,
        onSimulateFire: () -> Unit, onSimulatePollution: () -> Unit, onSimulateHumidity: () -> Unit
    ) {
        val scrollState = rememberScrollState()
        Column(modifier = Modifier.fillMaxSize().padding(16.dp).verticalScroll(scrollState)) {

            // --- HEADER AVEC LOGO ---
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // LOGO PERSONNALISÉ
                    // ATTENTION: Assure-toi d'avoir 'mon_logo.png' dans res/drawable !
                    Image(
                        painter = painterResource(id = R.drawable.mon_logo),
                        contentDescription = "Logo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(50.dp).clip(RoundedCornerShape(8.dp)).background(Color.White).border(1.dp, Color.LightGray, RoundedCornerShape(8.dp))
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("VENTILATION SYS", fontSize = 18.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace, color = SlateDark)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(if(isConnected) SuccessGreen else CriticalRed))
                            Spacer(Modifier.width(6.dp))
                            Text(if(isConnected) "ONLINE" else "OFFLINE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if(isConnected) SuccessGreen else CriticalRed, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
                if(isConnected) Button(onClick = onDisconnect, colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray.copy(alpha=0.2f)), contentPadding = PaddingValues(0.dp), modifier = Modifier.size(40.dp)) { Text("⏻", color = SlateDark) }
            }

            Spacer(Modifier.height(20.dp))

            if (!isConnected) {
                Box(modifier = Modifier.fillMaxWidth().height(200.dp).background(Color.LightGray.copy(alpha=0.1f), RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                    Text("NO SIGNAL", fontFamily = FontFamily.Monospace, color = Color.Gray)
                }
            } else {
                // 1. GRAPHIQUE
                Text("IAQ MONITORING (30s)", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray, fontFamily = FontFamily.Monospace)
                TechGraph(data = history, modifier = Modifier.fillMaxWidth().height(180.dp))

                Spacer(Modifier.height(20.dp))

                // 2. DATA CARDS
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TechDataCard("TEMP", "${temp.toInt()}°C", AlertOrange, Modifier.weight(1f))
                    TechDataCard("HUMID", "${hum.toInt()}%", TechBlue, Modifier.weight(1f))
                    TechDataCard("IAQ", "$iaq", if(iaq > 150) CriticalRed else SuccessGreen, Modifier.weight(1f))
                }

                Spacer(Modifier.height(20.dp))

                // 3. COMMANDES
                Text("MANUAL OVERRIDE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray, fontFamily = FontFamily.Monospace)
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    IndustrialButton("OPEN", SuccessGreen) { onCommand("1") }
                    IndustrialButton("STOP", Color.Gray) { onCommand("3") }
                    IndustrialButton("CLOSE", CriticalRed) { onCommand("2") }
                }

                Spacer(Modifier.height(25.dp))

                // 4. ZONE DE DIAGNOSTIC & SIMULATION (POUR LA DÉMO)
                Text("DIAGNOSTICS & SIMULATION", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray, fontFamily = FontFamily.Monospace)
                Spacer(Modifier.height(8.dp))

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onSimulateFire, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color.Black), shape = RoundedCornerShape(4.dp)) {
                        Text("🔥 FIRE", fontSize = 10.sp, color = AlertOrange, fontWeight = FontWeight.Bold)
                    }
                    Button(onClick = onSimulatePollution, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = SlateDark), shape = RoundedCornerShape(4.dp)) {
                        Text("☣️ TOXIC", fontSize = 10.sp, color = SensorCyan, fontWeight = FontWeight.Bold)
                    }
                    Button(onClick = onSimulateHumidity, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = SlateDark), shape = RoundedCornerShape(4.dp)) {
                        Text("💧 FLOOD", fontSize = 10.sp, color = TechBlue, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(Modifier.height(20.dp))

                // LOGS
                Text("SYSTEM LOGS", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray, fontFamily = FontFamily.Monospace)
                Box(modifier = Modifier.fillMaxWidth().height(150.dp).background(SlateDark, RoundedCornerShape(4.dp)).padding(10.dp)) {
                    LazyColumn { items(logs) { log -> Text("> $log", fontSize = 10.sp, color = SuccessGreen, fontFamily = FontFamily.Monospace) } }
                }
                Spacer(Modifier.height(50.dp))
            }
        }
    }

    // --- COMPOSANTS CUSTOM ---

    @Composable
    fun TechGraph(data: List<Int>, modifier: Modifier = Modifier) {
        Canvas(modifier = modifier.background(SurfaceWhite, RoundedCornerShape(4.dp)).border(1.dp, Color.LightGray.copy(0.3f), RoundedCornerShape(4.dp)).padding(10.dp)) {
            if (data.isEmpty()) return@Canvas
            val width = size.width; val height = size.height

            // Grille
            for (i in 0..5) drawLine(Color.LightGray.copy(0.2f), start = Offset(i * width / 5, 0f), end = Offset(i * width / 5, height))
            for (i in 0..3) drawLine(Color.LightGray.copy(0.2f), start = Offset(0f, i * height / 3), end = Offset(width, i * height / 3))

            // Courbe
            val maxVal = 500f
            val stepX = width / (data.size - 1).coerceAtLeast(1)
            val path = Path()
            data.forEachIndexed { i, value ->
                val x = i * stepX
                val y = height - (value / maxVal * height)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, color = TechBlue, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Square))

            // Remplissage
            val fillPath = Path(); fillPath.addPath(path); fillPath.lineTo(width, height); fillPath.lineTo(0f, height); fillPath.close()
            drawPath(fillPath, brush = Brush.verticalGradient(listOf(TechBlue.copy(0.2f), Color.Transparent)))
        }
    }

    @Composable
    fun TechDataCard(label: String, value: String, accent: Color, modifier: Modifier) {
        Column(modifier = modifier.background(SurfaceWhite, RoundedCornerShape(4.dp)).border(1.dp, Color.LightGray.copy(0.3f), RoundedCornerShape(4.dp)).padding(12.dp)) {
            Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray, fontFamily = FontFamily.Monospace)
            Spacer(Modifier.height(4.dp))
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = accent, fontFamily = FontFamily.Monospace)
        }
    }

    @Composable
    fun RowScope.IndustrialButton(text: String, color: Color, onClick: () -> Unit) {
        Button(
            onClick = onClick, modifier = Modifier.weight(1f).height(60.dp),
            colors = ButtonDefaults.buttonColors(containerColor = color),
            shape = RoundedCornerShape(6.dp), elevation = ButtonDefaults.buttonElevation(2.dp)
        ) { Text(text, fontSize = 14.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace) }
    }

    @Composable
    fun FireAlertOverlay(temp: Float, onDisable: () -> Unit) {
        val infiniteTransition = rememberInfiniteTransition()
        val color by infiniteTransition.animateColor(
            initialValue = CriticalRed, targetValue = Color(0xFF500000),
            animationSpec = infiniteRepeatable(animation = tween(600, easing = FastOutSlowInEasing), repeatMode = RepeatMode.Reverse), label = "siren"
        )
        val scale by infiniteTransition.animateFloat(
            initialValue = 1f, targetValue = 1.1f,
            animationSpec = infiniteRepeatable(animation = tween(600), repeatMode = RepeatMode.Reverse), label = "pulse"
        )

        Box(modifier = Modifier.fillMaxSize().background(Brush.radialGradient(listOf(color, Color.Black))).clickable {}, contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.scale(scale)) {
                Text("⚠️", fontSize = 100.sp)
                Text("CRITICAL ALERT", color = SurfaceWhite, fontWeight = FontWeight.Black, fontSize = 40.sp, fontFamily = FontFamily.Monospace)
                Spacer(Modifier.height(10.dp))
                Text("FIRE PROTOCOL INITIATED", color = AlertOrange, fontSize = 20.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                Text("TEMP: ${temp.toInt()}°C", color = SurfaceWhite, fontSize = 30.sp, fontFamily = FontFamily.Monospace)
                Spacer(Modifier.height(50.dp))
                Button(onClick = onDisable, colors = ButtonDefaults.buttonColors(containerColor = SurfaceWhite), modifier = Modifier.height(60.dp)) {
                    Text("SYSTEM RESET / STOP", color = CriticalRed, fontWeight = FontWeight.Black, fontSize = 18.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("VENT_NOTIF", "Alerte", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    @SuppressLint("MissingPermission")
    private fun sendNotif(title: String, content: String) {
        val builder = NotificationCompat.Builder(this, "VENT_NOTIF").setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle(title).setContentText(content).setPriority(NotificationCompat.PRIORITY_HIGH)
        NotificationManagerCompat.from(this).notify(Random.nextInt(), builder.build())
    }
    private fun getTime(): String = java.text.SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
}